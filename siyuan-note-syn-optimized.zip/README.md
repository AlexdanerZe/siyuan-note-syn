
# SiYuan Diary Progress Sync Plugin

[中文版](./README_zh_CN.md)

A specialized plugin for SiYuan Note that automatically extracts and synchronizes project progress information from diary documents.

## Features

### 🎯 Core Functions

- **Smart Progress Extraction**: Automatically identifies and extracts project progress information from diary documents
- **Flexible Date Format Support**: Supports multiple date formats (YYYY-MM-DD, YYYY/MM/DD, YYYY年MM月DD日, etc.)
- **Project Reference Recognition**: Automatically recognizes project references and related progress descriptions in documents
- **Notebook Limitation Search**: Can limit searches to specific notebooks for diary content
- **Leaf Document Filtering**: Supports option to search only leaf documents for improved search precision

### ⚙️ Configuration Options

- **Auto Sync Toggle**: Enable or disable automatic synchronization functionality
- **Path Configuration**: Customize diary path and project path
- **Content Title Configuration**: Configure the title name for content extraction
- **Notebook Selection**: Support for selecting specific notebooks for limited search
- **Custom Date Format**: Support for custom configuration of multiple date formats

### 🔧 Technical Features

- **Real-time Sync**: Supports real-time monitoring and synchronization functionality
- **Error Handling**: Comprehensive error handling and logging mechanisms
- **Performance Optimization**: Efficient document search and content extraction algorithms
- **User-friendly Interface**: Intuitive settings interface, easy to configure and use

## Installation

### Method 1: Install from Source

1. Clone or download this project locally
2. Install dependencies: `npm install` or `pnpm install`
3. Build plugin: `npm run build` or `pnpm run build`
4. Extract the generated `package.zip` file to SiYuan Note's plugin directory

### Method 2: Development Mode

1. Clone project to local development directory
2. Install dependencies: `pnpm install`
3. Create symbolic link: `pnpm run make-link`
4. Start development mode: `pnpm run dev`
5. Enable plugin in SiYuan Note

## Usage Guide

### Basic Configuration

1. **Open Plugin Settings**
   - Find plugin management in SiYuan Note
   - Click the settings button for "SiYuan Diary Progress Sync" plugin

2. **Configure Basic Parameters**
   - **Diary Path**: Set the storage path for diary documents
   - **Project Path**: Set the storage path for project documents
   - **Date Format**: Select or customize date format
   - **Content Title**: Set the title name for content extraction

3. **Notebook Limitation Settings**
   - Enable "Enable Notebook Limitation" option
   - Select specific notebook to search
   - Optionally choose "Search Only Leaf Documents" for improved search precision

### Advanced Features

#### Auto Sync

- Enable "Auto Sync" functionality in settings
- Plugin will automatically monitor changes in diary documents
- Automatically synchronizes when new progress information is detected

#### Manual Sync

- Manually trigger sync through plugin interface
- Supports test configuration functionality to verify settings are correct

#### Progress Format

The plugin supports recognizing progress information in the following format:

```markdown
## 2024-01-15

### Project Progress
- [[Project A]] Completed feature module development
- [[Project B]] Fixed critical bugs, ready for release
- [[Project C]] Started new requirement analysis

### Daily Summary
Project progress is smooth, mainly completed...
```

## Configuration Examples

### Basic Configuration Example

```json
{
  "diaryPath": "/daily_notes/",
  "projectPath": "/projects/",
  "dateFormat": "YYYY-MM-DD",
  "contentTitle": "Project Progress",
  "autoSyncEnabled": true,
  "enableNotebookLimitation": true,
  "selectedNotebookId": "20240101-notebook-id",
  "onlyLeafDocuments": true
}
```

### Supported Date Formats

- `YYYY-MM-DD`: 2024-01-15
- `YYYY/MM/DD`: 2024/01/15
- `YYYY年MM月DD日`: 2024年01月15日
- `MM-DD-YYYY`: 01-15-2024
- `DD/MM/YYYY`: 15/01/2024

## Troubleshooting

### Common Issues

1. **Cannot Find Diary Documents**
   - Check if diary path configuration is correct
   - Confirm date format settings match actual document titles

2. **Inaccurate Progress Extraction**
   - Check if content title configuration is correct
   - Confirm document title format meets requirements

3. **Notebook Limitation Not Working**
   - Confirm notebook limitation functionality is enabled
   - Check if selected notebook ID is correct

### Debug Mode

The plugin provides detailed logging functionality:

- View console logs in developer tools
- Logs include detailed execution steps and error information
- Use logs to locate specific issues

## Development Guide

### Tech Stack

- **Frontend Framework**: Svelte
- **Build Tool**: Vite
- **Language**: TypeScript
- **API**: SiYuan Note Plugin API

### Project Structure

```
src/
├── index.ts              # Plugin entry file
├── sync-service.ts       # Sync service core logic
├── notebook-service.ts   # Notebook service
├── notebook-settings.svelte # Settings interface component
└── utils/               # Utility functions
```

### Development Environment Setup

1. Install Node.js and pnpm
2. Clone project: `git clone <repository-url>`
3. Install dependencies: `pnpm install`
4. Start development: `pnpm run dev`

## Contributing

Welcome to submit Issues and Pull Requests to improve this plugin!

### Submit Issues

- Please describe the problem and reproduction steps in detail
- Provide relevant configuration information and error logs
- Specify the SiYuan Note version being used

### Submit Code

- Fork this project
- Create feature branch
- Submit code with clear commit messages
- Create Pull Request

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) file for details.

## Changelog

### v0.1.0
- Initial version release
- Implemented basic diary progress extraction functionality
- Support for notebook limitation search
- Provided complete settings interface

## Support

If this plugin is helpful to you, welcome to:

- ⭐ Star the project
- 🐛 Report bugs and suggestions
- 💡 Propose new feature ideas
- 📖 Improve documentation

---

**Note**: This plugin requires SiYuan Note v2.8.8 or higher.

