"use strict";var v=Object.defineProperty;var b=(r,s,t)=>s in r?v(r,s,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[s]=t;var c=(r,s,t)=>b(r,typeof s!="symbol"?s+"":s,t);const a=require("siyuan");async function g(r,s){try{const t=await a.fetchSyncPost(r,s);return t.code===0?t.data:(console.error(`API请求失败 (${r}):`,t.msg),null)}catch(t){throw console.error(`API请求异常 (${r}):`,t),t}}class h{constructor(s){c(this,"config");c(this,"documentCache",new Map);c(this,"CACHE_DURATION",5*60*1e3);this.config=s}updateConfig(s){this.config=s,this.clearCache()}clearCache(){this.documentCache.clear(),console.log("🧹 文档缓存已清理")}async sync(){try{console.log("🚀 开始简化版同步流程...");const s=await this.getDiaryEntries();if(console.log(`📖 找到 ${s.length} 条日记内容`),s.length===0)return console.log("ℹ️ 没有找到日记内容，同步完成"),{success:!0,projectCount:0,contentCount:0};const t=this.groupByProject(s),e=Object.keys(t);console.log(`📁 识别出 ${e.length} 个项目: ${e.join(", ")}`);let n=0,o=0;const i=[];for(const[d,u]of Object.entries(t))try{console.log(`🔄 正在同步项目 "${d}"...`),await this.syncToProject(d,u),n+=u.length,o++,console.log(`✅ 项目 "${d}" 同步完成，${u.length} 条内容`)}catch(f){const y=`项目 "${d}" 同步失败: ${f.message||f}`;console.error(`❌ ${y}`),i.push(y)}const p=i.length===0,m=p?`🎉 同步完成！总计处理 ${o} 个项目，${n} 条内容`:`⚠️ 部分同步完成！成功 ${o} 个项目，失败 ${i.length} 个项目`;return console.log(m),i.length>0&&console.error("同步错误详情:",i),{success:p,projectCount:o,contentCount:n,error:i.length>0?i.join("; "):void 0}}catch(s){const t=s.message||"未知错误";return console.error("❌ 同步失败:",s),{success:!1,projectCount:0,contentCount:0,error:t}}}async testConfiguration(){try{const s=await this.findDocuments(this.config.diaryPath);console.log(`📖 日记路径测试: 找到 ${s.length} 个文档`);const t=await this.findDocuments(this.config.projectPath);return console.log(`📁 项目路径测试: 找到 ${t.length} 个文档`),{success:!0,diaryCount:s.length,projectCount:t.length}}catch(s){return console.error("❌ 配置测试失败:",s),{success:!1,diaryCount:0,projectCount:0,error:s.message||String(s)}}}async getDiaryEntries(){const s=[];try{const t=await this.findDocuments(this.config.diaryPath);for(const e of t)try{const n=await this.getDocumentContent(e.id),o=this.extractProgressContent(n);if(o.trim()){const i=this.extractProjectName(o);i&&!this.isCommonNonProjectName(i)&&s.push({id:e.id,content:o,date:this.extractDateFromTitle(e.content)||e.content,projectName:i})}}catch(n){console.warn(`⚠️ 处理日记文档 ${e.id} 失败:`,n)}}catch(t){throw console.error("❌ 获取日记条目失败:",t),t}return s}async findDocuments(s){try{const t=s.replace(/'/g,"''"),e=await g("/api/query/sql",{stmt:`SELECT id, content FROM blocks WHERE type='d' AND content LIKE '%${t}%' ORDER BY updated DESC LIMIT 100`});return(e==null?void 0:e.data)||[]}catch(t){return console.error(`❌ 查找文档失败 (${s}):`,t),[]}}async getDocumentContent(s){try{const t=this.documentCache.get(s),e=Date.now();if(t&&e-t.timestamp<this.CACHE_DURATION)return t.content;const n=s.replace(/'/g,"''"),o=await g("/api/query/sql",{stmt:`SELECT markdown FROM blocks WHERE id='${n}' AND type='d'`});let i="";return o!=null&&o.data&&o.data.length>0&&(i=o.data[0].markdown||""),this.documentCache.set(s,{content:i,timestamp:e}),i}catch(t){return console.error(`❌ 获取文档内容失败 (${s}):`,t),""}}extractProgressContent(s){const t=s.split(`
`);let e=!1,n=[];for(const o of t){if(o.trim()===this.config.progressSection.trim()){e=!0;continue}if(e){if(o.trim().startsWith("#")&&o.trim()!==this.config.progressSection.trim())break;n.push(o)}}return n.join(`
`).trim()}extractProjectName(s){const t=[/\[\[([^|\]]+)(?:\|[^\]]+)?\]\]/,/\(\(([^)]+)\)\)/,/【([^】]+)】/,/\*\*([^*]+)\*\*/,/^[•\-\*]\s*([^：:]+)[：:]/m];for(const e of t){const n=s.match(e);if(n&&n[1]){const o=n[1].trim();if(o.length>1&&o.length<50)return o}}return""}isCommonNonProjectName(s){return["今日","明天","昨天","本周","下周","上周","今天","工作","学习","生活","其他","杂项","待办","计划","总结","思考","笔记","记录"].includes(s.toLowerCase())||/^\d{4}-\d{2}-\d{2}$/.test(s)||s.length<2||s.length>30}groupByProject(s){const t={};for(const e of s)t[e.projectName]||(t[e.projectName]=[]),t[e.projectName].push(e);return t}async syncToProject(s,t){try{const e=await this.findOrCreateProjectDoc(s),n=await this.getDocumentContent(e.id),o=this.generateProjectContent(n,t);await this.updateDocument(e.id,o)}catch(e){throw console.error(`❌ 同步到项目 "${s}" 失败:`,e),e}}async findOrCreateProjectDoc(s){const t=await this.findDocuments(s);for(const e of t)if(e.content.includes(s))return e;try{const e=await g("/api/filetree/createDoc",{notebook:this.config.projectPath,path:`/${s}`,title:s,md:`# ${s}

## 项目进展

`});if(e.data)return{id:e.data,content:s}}catch(e){console.error(`❌ 创建项目文档失败 (${s}):`,e)}throw new Error(`无法找到或创建项目文档: ${s}`)}generateProjectContent(s,t){let e=s;e.trim()||(e=`# ${t[0].projectName}

## 项目进展

`);for(const n of t){const o=n.date,i=this.cleanContent(n.content);e+=`### ${o}

${i}

`}return e}cleanContent(s){return s.replace(/\{\{[^}]+\}\}/g,"").replace(/\*\*([^*]+)\*\*/g,"$1").replace(/\s+/g," ").trim()}async updateDocument(s,t){try{await g("/api/block/updateBlock",{id:s,data:t,dataType:"markdown"})}catch(e){throw console.error(`❌ 更新文档失败 (${s}):`,e),e}}extractDateFromTitle(s){const t=/(\d{4}-\d{2}-\d{2})/,e=s.match(t);return e?e[1]:null}}const l="sync-config";class C extends a.Plugin{constructor(){super(...arguments);c(this,"syncService",null);c(this,"config",{diaryPath:"日记",projectPath:"项目",progressSection:"## 今日进展",autoSyncEnabled:!1,autoSyncDelay:1e4})}async onload(){console.log("🚀 简化版日记同步插件开始加载...");try{await this.initializeConfig(),this.syncService=new h(this.config),this.addCommand({langKey:"manual-sync",hotkey:"⌘⇧S",callback:()=>this.manualSync()}),this.addCommand({langKey:"open-settings",hotkey:"⌘⇧P",callback:()=>this.openSettings()}),console.log("✅ 简化版插件加载完成"),a.showMessage("📝 日记同步插件已就绪",3e3)}catch(t){console.error("❌ 插件加载失败:",t),a.showMessage("插件加载失败，请查看控制台",5e3)}}onLayoutReady(){this.addTopBar({icon:"iconRefresh",title:"日记同步",position:"right",callback:()=>{this.showQuickMenu()}})}showQuickMenu(){const t=new a.Menu("sync-menu");t.addItem({icon:"iconRefresh",label:"手动同步",click:()=>this.manualSync()}),t.addItem({icon:"iconSettings",label:"打开设置",click:()=>this.openSettings()}),t.addSeparator(),t.addItem({icon:"iconInfo",label:"查看状态",click:()=>this.showStatus()}),t.open({x:window.innerWidth-200,y:50})}async manualSync(){if(!this.syncService){a.showMessage("同步服务未初始化",3e3);return}try{a.showMessage("🚀 开始同步...",2e3),console.log("🚀 开始手动同步...");const t=await this.syncService.sync();if(t.success){const e=`✅ 同步完成！处理了 ${t.projectCount} 个项目，${t.contentCount} 条内容`;console.log(e),a.showMessage(e,4e3)}else{const e=`❌ 同步失败: ${t.error}`;console.error(e),a.showMessage(e,5e3)}}catch(t){const e=`同步异常: ${t.message||t}`;console.error("❌ 同步异常:",t),a.showMessage(e,5e3)}}openSettings(){const t=new a.Dialog({title:"日记同步设置",content:this.generateSettingsHTML(),width:"600px",height:"500px"});this.bindSettingsEvents(t)}generateSettingsHTML(){return`
            <div class="sync-settings">
                <div class="setting-item">
                    <label>日记路径:</label>
                    <input type="text" id="diary-path" value="${this.config.diaryPath}" placeholder="例如: 日记">
                    <div class="setting-hint">日记文档所在的路径或笔记本名称</div>
                </div>
                
                <div class="setting-item">
                    <label>项目路径:</label>
                    <input type="text" id="project-path" value="${this.config.projectPath}" placeholder="例如: 项目">
                    <div class="setting-hint">项目文档所在的路径或笔记本名称</div>
                </div>
                
                <div class="setting-item">
                    <label>进展区块标题:</label>
                    <input type="text" id="progress-section" value="${this.config.progressSection}" placeholder="例如: ## 今日进展">
                    <div class="setting-hint">日记中进展内容的标题</div>
                </div>
                
                <div class="setting-item">
                    <label>
                        <input type="checkbox" id="auto-sync" ${this.config.autoSyncEnabled?"checked":""}>
                        启用自动同步
                    </label>
                    <div class="setting-hint">编辑日记时自动触发同步</div>
                </div>
                
                <div class="setting-item">
                    <label>自动同步延迟 (毫秒):</label>
                    <input type="number" id="auto-sync-delay" value="${this.config.autoSyncDelay}" min="1000" max="60000">
                    <div class="setting-hint">编辑停止后多久触发同步</div>
                </div>
                
                <div class="setting-actions">
                    <button id="test-config" class="b3-button b3-button--outline">测试配置</button>
                    <button id="save-config" class="b3-button">保存设置</button>
                </div>
                
                <div id="test-result" class="test-result"></div>
            </div>
            
            <style>
                .sync-settings {
                    padding: 20px;
                }
                .setting-item {
                    margin-bottom: 20px;
                }
                .setting-item label {
                    display: block;
                    margin-bottom: 5px;
                    font-weight: bold;
                }
                .setting-item input[type="text"],
                .setting-item input[type="number"] {
                    width: 100%;
                    padding: 8px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
                .setting-hint {
                    font-size: 12px;
                    color: #666;
                    margin-top: 5px;
                }
                .setting-actions {
                    margin-top: 30px;
                    text-align: right;
                }
                .setting-actions button {
                    margin-left: 10px;
                }
                .test-result {
                    margin-top: 15px;
                    padding: 10px;
                    border-radius: 4px;
                    display: none;
                }
                .test-result.success {
                    background-color: #d4edda;
                    color: #155724;
                    border: 1px solid #c3e6cb;
                }
                .test-result.error {
                    background-color: #f8d7da;
                    color: #721c24;
                    border: 1px solid #f5c6cb;
                }
            </style>
        `}bindSettingsEvents(t){var n,o;const e=t.element;(n=e.querySelector("#test-config"))==null||n.addEventListener("click",async()=>{await this.testConfiguration(e)}),(o=e.querySelector("#save-config"))==null||o.addEventListener("click",async()=>{await this.saveConfiguration(e,t)})}async testConfiguration(t){const e=t.querySelector("#test-result");e.style.display="block",e.className="test-result",e.textContent="正在测试配置...";try{const n=this.getConfigFromForm(t),i=await new h(n).testConfiguration();i.success?(e.className="test-result success",e.textContent=`✅ 配置测试成功！找到 ${i.diaryCount} 个日记文档，${i.projectCount} 个项目文档`):(e.className="test-result error",e.textContent=`❌ 配置测试失败: ${i.error}`)}catch(n){e.className="test-result error",e.textContent=`❌ 测试异常: ${n.message||n}`}}async saveConfiguration(t,e){try{const n=this.getConfigFromForm(t),o=this.validateConfigObject(n);if(!o.valid){a.showMessage(`❌ 配置验证失败: ${o.error}`,4e3);return}this.data[l]=n,await this.saveData(l,n),this.config=n,this.syncService?this.syncService.updateConfig(this.config):this.syncService=new h(this.config),a.showMessage("✅ 设置已保存",3e3),console.log("✅ 插件配置已更新"),e.destroy()}catch(n){console.error("❌ 保存配置失败:",n),a.showMessage(`❌ 保存配置失败: ${n.message||n}`,4e3)}}getConfigFromForm(t){return{diaryPath:t.querySelector("#diary-path").value.trim(),projectPath:t.querySelector("#project-path").value.trim(),progressSection:t.querySelector("#progress-section").value.trim(),autoSyncEnabled:t.querySelector("#auto-sync").checked,autoSyncDelay:parseInt(t.querySelector("#auto-sync-delay").value)}}showStatus(){new a.Dialog({title:"插件状态",content:this.generateStatusHTML(),width:"500px",height:"400px"})}generateStatusHTML(){const t=this.syncService?"✅ 已初始化":"❌ 未初始化",e=this.validateConfig();return`
            <div class="status-container">
                <div class="status-section">
                    <h3>🔧 服务状态</h3>
                    <div class="status-item">
                        <span class="label">同步服务:</span>
                        <span class="value">${t}</span>
                    </div>
                    <div class="status-item">
                        <span class="label">配置状态:</span>
                        <span class="value">${e.valid?"✅ 有效":"❌ 无效"}</span>
                    </div>
                    ${e.valid?"":`<div class="error-msg">错误: ${e.error}</div>`}
                </div>

                <div class="status-section">
                    <h3>⚙️ 当前配置</h3>
                    <div class="config-item">
                        <span class="label">日记路径:</span>
                        <span class="value">${this.config.diaryPath}</span>
                    </div>
                    <div class="config-item">
                        <span class="label">项目路径:</span>
                        <span class="value">${this.config.projectPath}</span>
                    </div>
                    <div class="config-item">
                        <span class="label">进展标题:</span>
                        <span class="value">${this.config.progressSection}</span>
                    </div>
                    <div class="config-item">
                        <span class="label">自动同步:</span>
                        <span class="value">${this.config.autoSyncEnabled?"✅ 启用":"❌ 禁用"}</span>
                    </div>
                    <div class="config-item">
                        <span class="label">同步延迟:</span>
                        <span class="value">${this.config.autoSyncDelay}ms</span>
                    </div>
                </div>

                <div class="status-section">
                    <h3>📊 插件信息</h3>
                    <div class="info-item">
                        <span class="label">版本:</span>
                        <span class="value">1.0.0 (简化版)</span>
                    </div>
                    <div class="info-item">
                        <span class="label">状态:</span>
                        <span class="value">运行中</span>
                    </div>
                </div>
            </div>

            <style>
                .status-container {
                    padding: 20px;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }
                .status-section {
                    margin-bottom: 25px;
                    padding: 15px;
                    border: 1px solid #e0e0e0;
                    border-radius: 8px;
                    background-color: #fafafa;
                }
                .status-section h3 {
                    margin: 0 0 15px 0;
                    color: #333;
                    font-size: 16px;
                }
                .status-item, .config-item, .info-item {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 8px;
                    padding: 5px 0;
                }
                .label {
                    font-weight: 500;
                    color: #666;
                }
                .value {
                    color: #333;
                    font-family: monospace;
                }
                .error-msg {
                    color: #d32f2f;
                    font-size: 12px;
                    margin-top: 10px;
                    padding: 8px;
                    background-color: #ffebee;
                    border-radius: 4px;
                }
            </style>
        `}validateConfig(){return this.validateConfigObject(this.config)}validateConfigObject(t){return t.diaryPath.trim()?t.projectPath.trim()?t.progressSection.trim()?t.autoSyncDelay<1e3?{valid:!1,error:"自动同步延迟不能小于1000ms"}:{valid:!0}:{valid:!1,error:"进展标题不能为空"}:{valid:!1,error:"项目路径不能为空"}:{valid:!1,error:"日记路径不能为空"}}async initializeConfig(){this.data[l]?this.config={...this.config,...this.data[l]}:(this.data[l]=this.config,await this.saveData(l,this.config)),console.log("📋 配置已初始化:",this.config)}async onunload(){console.log("👋 简化版插件正在卸载..."),this.syncService=null}openSetting(){this.openSettings()}}module.exports=C;
